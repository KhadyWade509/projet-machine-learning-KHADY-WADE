"""Prediction : charge models/model.joblib (Pipeline complet) et predit."""
from pathlib import Path

import joblib
import pandas as pd

MODEL_PATH = Path(__file__).resolve().parent.parent / "models" / "model.joblib"
_modele = None


def _charger():
    global _modele
    if _modele is None:
        _modele = joblib.load(MODEL_PATH)
    return _modele


def predict(df: pd.DataFrame) -> list:
    """df : memes colonnes que flux_train.csv, SANS 'attaque'.
    Retourne une liste de 0 (normal) ou 1 (attaque), une valeur par ligne."""
    X = df.drop(columns=["attaque"], errors="ignore")
    return [int(p) for p in _charger().predict(X)]


if __name__ == "__main__":
    donnees = pd.read_csv(Path(__file__).resolve().parent.parent / "data" / "flux_train.csv")
    print(predict(donnees.head(10)))
