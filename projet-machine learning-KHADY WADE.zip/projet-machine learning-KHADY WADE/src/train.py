"""Projet 2 - Detection d'attaques reseau avec le Machine Learning.

Lancer depuis la racine du depot : python src/train.py
Etapes : exploration, comparaison de modeles sur un jeu de validation,
choix du meilleur (F1 de la classe attaque), reentrainement sur toutes
les donnees, sauvegarde dans models/model.joblib.
"""
from pathlib import Path

import joblib
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (classification_report, confusion_matrix, f1_score,
                             precision_score, recall_score)
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.tree import DecisionTreeClassifier

BASE = Path(__file__).resolve().parent.parent
DATA = BASE / "data" / "flux_train.csv"
MODEL = BASE / "models" / "model.joblib"
CIBLE = "attaque"
SEED = 42


def explorer(df: pd.DataFrame) -> None:
    print("Taille :", df.shape)
    print("\nValeurs manquantes :\n", df.isna().sum())
    print("\nRepartition de la cible :\n", df[CIBLE].value_counts(normalize=True).round(3))


def construire_pretraitement(X: pd.DataFrame) -> ColumnTransformer:
    num = [c for c in X.columns if c != "protocol"]
    return ColumnTransformer([
        ("num", Pipeline([("imputer", SimpleImputer(strategy="median")),
                          ("scaler", StandardScaler())]), num),
        ("cat", OneHotEncoder(handle_unknown="ignore"), ["protocol"]),
    ])


def modeles(X: pd.DataFrame) -> dict:
    """Un Pipeline complet (pretraitement + modele) par candidat."""
    candidats = {
        "Regression logistique": LogisticRegression(max_iter=1000, class_weight="balanced"),
        "Arbre de decision": DecisionTreeClassifier(max_depth=6, class_weight="balanced",
                                                    random_state=SEED),
        "Foret aleatoire": RandomForestClassifier(n_estimators=300, class_weight="balanced",
                                                  random_state=SEED, n_jobs=-1),
    }
    return {nom: Pipeline([("prep", construire_pretraitement(X)), ("model", m)])
            for nom, m in candidats.items()}


def main() -> None:
    df = pd.read_csv(DATA)
    explorer(df)
    X, y = df.drop(columns=[CIBLE]), df[CIBLE]

    X_tr, X_val, y_tr, y_val = train_test_split(
        X, y, test_size=0.2, stratify=y, random_state=SEED)

    resultats = {}
    for nom, pipe in modeles(X).items():
        pipe.fit(X_tr, y_tr)
        pred = pipe.predict(X_val)
        resultats[nom] = {
            "F1": f1_score(y_val, pred),
            "Rappel": recall_score(y_val, pred),
            "Precision": precision_score(y_val, pred),
        }
        print(f"\n===== {nom} =====")
        print(classification_report(y_val, pred, target_names=["normal", "attaque"]))
        tn, fp, fn, tp = confusion_matrix(y_val, pred).ravel()
        print(f"Matrice de confusion : VN={tn} FP={fp} FN={fn} VP={tp}")

    tableau = pd.DataFrame(resultats).T.round(3)
    print("\nComparaison (classe attaque) :\n", tableau)

    meilleur = tableau["F1"].idxmax()
    print("\nModele retenu :", meilleur)

    # Reentrainement sur toutes les donnees puis sauvegarde
    final = modeles(X)[meilleur]
    final.fit(X, y)
    MODEL.parent.mkdir(exist_ok=True)
    joblib.dump(final, MODEL)
    print("Modele enregistre dans", MODEL)


if __name__ == "__main__":
    main()
