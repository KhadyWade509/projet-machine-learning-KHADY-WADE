# Projet 2 — Détecter des attaques réseau avec le Machine Learning

## Lancer le projet
```bash
pip install -r requirements.txt
python src/train.py      # entraîne, compare les modèles, enregistre models/model.joblib
python src/predict.py    # petit test de la fonction predict
```
`predict(df)` (dans `src/predict.py`) charge `models/model.joblib` (un `Pipeline` qui inclut
le prétraitement) et renvoie une liste de 0 (normal) ou 1 (attaque).

## Résultats

**Nom / Prénom :** KHADY WADE

**Données :** 3000 flux, 28 % d'attaques, 90 valeurs manquantes (`duration`). Validation :
20 % des données (600 flux), découpage stratifié.

**Prétraitement (dans un `Pipeline`)** : imputation par la médiane, mise à l'échelle
(`StandardScaler`) et encodage one-hot de `protocol`. Les classes sont pondérées
(`class_weight="balanced"`) à cause du déséquilibre.

| Modèle | F1 (attaque) | Rappel (attaque) | Précision (attaque) |
|---|---|---|---|
| Régression logistique | 0,920 | 0,898 | 0,943 |
| Arbre de décision (profondeur 6) | 0,953 | 0,964 | 0,942 |
| Forêt aléatoire (300 arbres) | **0,982** | **0,976** | **0,988** |

Contrôle par validation croisée 5 plis (F1 moyen) : régression logistique 0,896 ;
arbre 0,935 ; forêt aléatoire 0,960. Le classement est le même.

**Modèle retenu et pourquoi :** la forêt aléatoire, la meilleure sur les trois mesures et
aussi en validation croisée. Elle capture les relations non linéaires (par exemple
`nb_conn_same_host` élevé combiné à un `syn_rate` élevé). Elle a ensuite été ré-entraînée sur
toutes les données avant l'enregistrement dans `models/model.joblib`.

**Analyse des erreurs :** matrice de confusion de la forêt sur la validation :

| | Prédit normal | Prédit attaque |
|---|---|---|
| Réel normal | 431 | 2 |
| Réel attaque | 4 | 163 |

- **4 faux négatifs** (attaques ratées) : c'est le pire cas en sécurité, car une attaque passe
  inaperçue et peut réussir (intrusion, déni de service) sans alerte.
- **2 faux positifs** (flux normaux signalés) : ils coûtent du temps d'analyse et des
  fausses alertes, mais restent moins graves qu'une attaque non détectée.
- Pistes : abaisser le seuil de décision pour augmenter le rappel, ou ajouter des variables
  (ex. rythme des connexions dans le temps).
